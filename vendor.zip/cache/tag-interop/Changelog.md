# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 1.1.0

* Support PHP 8.1
* Support for psr/cache v2

## 1.0.1

* Support PHP 8

## 1.0.0

* First release


